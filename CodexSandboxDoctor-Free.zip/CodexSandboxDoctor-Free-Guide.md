# CODEX SANDBOX DOCTOR FREE
# OFFICIAL USER GUIDE / 공식 사용설명서

**Version:** STAGE003-B  
**Product:** Codex Sandbox Doctor Free  
**Platform:** Windows  
**Price:** Free  
**Languages:** English / Korean

---

# PART 1 — ENGLISH USER GUIDE

## 1. Introduction

Codex Sandbox Doctor Free is a Windows diagnostic program designed to help users identify common OpenAI Codex CLI execution problems.

Sometimes Codex opens normally, but the terminal commands inside Codex fail to execute. Codex Sandbox Doctor Free helps you understand these issues by checking the installed Codex environment and analyzing saved error logs.

**Codex Sandbox Doctor Free is completely free to use.**

It provides diagnostics and reports. Automatic recovery and verified sandbox recovery commands are available separately in Codex Sandbox Doctor Pro.

## 2. Download and launch

**Step 1 — Start Codex Sandbox Doctor Free**

1. Download `CodexSandboxDoctor-Free.zip` from the official release page.
2. Extract the ZIP file to a folder on your computer.
3. Double-click `CodexSandboxDoctor-Free.exe`.
4. The Free diagnostic window will open.

No PowerShell commands are required.

**Screenshot 01 — English startup screen**

![Screenshot 01](images/01.jpg)

The initial screen explains what the application checks, including the installed Codex version, diagnostic log location, and inspection scope.

You do not need to select an individual project folder.

## 3. Select your language

**Step 2 — Choose English or Korean**

Use the language selection menu at the top of the program.

Choose `English` or `한국어`.

**Screenshot 02 — Korean startup screen**

![Screenshot 02](images/02.jpg)

The application supports both languages. The detailed report also provides Korean explanations for common error messages.

## 4. Run the free diagnostic

**Step 3 — Click "Run Free Diagnostic"**

Click the `Run Free Diagnostic` button.

The application will check:

- Codex CLI installation status
- Installed Codex CLI version
- Codex executable location
- Saved Windows sandbox diagnostic logs
- Common error patterns
- Historical error counts
- Related running processes

The Free diagnostic does not intentionally modify your Codex settings, authentication credentials, or existing sessions.

**Screenshot 03 — Diagnostic result**

![Screenshot 03](images/03.jpg)

### Understanding the results

**Diagnostic Execution: PASS**

The diagnostic was completed successfully.

**Historical Errors Found**

The program found recorded errors in previously saved logs.

**Current Error Reproduction: Not Tested**

The Free edition has not attempted to reproduce the error during the current session.

**Recovery Execution: Not Run**

No recovery operation was performed.

These results are independent. A successfully completed diagnostic does not mean Codex has already been repaired.

## 5. View the detailed report

**Step 4 — Click "View Report"**

After the diagnostic finishes, click `View Report`.

A text report will open and display the diagnostic findings.

**Screenshot 04 — Detailed report**

![Screenshot 04](images/04.jpg)

The report includes the inspected Codex version, log time range, total historical error matches, and explanations for known errors.

### Common Codex errors

**A. `setup refresh had errors`**

The Windows Codex sandbox initialization or refresh process reported an error.

This may prevent Codex from executing terminal commands even when the Codex interface opens successfully.

**B. `helper_unknown_error`**

The Codex execution helper reported an unknown initialization error.

Additional execution evidence may be needed to identify the specific cause.

**C. `os error 32`**

Windows recorded a file-sharing conflict.

This can happen when a process is using a file that another operation needs to update or access.

**D. `os error 5`**

Windows reported an access-denied error.

This can be associated with permissions or execution environment restrictions.

### Historical errors versus current errors

The number of errors shown in the report is the number of matching records found in previously saved logs.

For example, 300 historical errors do not mean that 300 errors are currently occurring.

## 6. What Codex Sandbox Doctor Free can diagnose

The Free edition supports:

1. Detecting whether Codex CLI is installed.
2. Identifying the installed Codex version.
3. Locating the Codex executable.
4. Inspecting available sandbox diagnostic logs.
5. Detecting supported error messages.
6. Counting historical error records.
7. Showing related process information.
8. Generating a diagnostic report.

### What Free does not do

The Free edition does not:

- Automatically repair Codex.
- Change Windows sandbox settings.
- Terminate active Codex sessions.
- Fix every authentication or login error.
- Repair all npm or Node.js installation problems.
- Fix internet, network, or server outages.
- Guarantee detection of every new or unknown Codex error.
- Generate verified recovery terminal commands.

These recovery-related features are outside the Free edition's scope.

## 7. Do I need to keep Codex open?

No.

You can use Codex Sandbox Doctor Free whether the problematic Codex window is open or closed.

The program primarily inspects the installed Codex CLI environment and saved diagnostic records.

If the affected Codex session is still running, keeping it open may provide additional information about currently running processes, but it is not required.

## 8. Understanding PASS, PARTIAL, HOLD, and FAIL

**PASS**

The specific diagnostic or test completed successfully.

**PARTIAL**

Some evidence is available, but not everything required for the complete operation has been verified.

**HOLD**

The requested operation cannot currently be confirmed or safely completed.

**FAIL**

The specific operation failed according to the available evidence.

**Important:** Diagnostic success and recovery success are different results.

## 9. Continue development with Codex Sandbox Doctor Pro

If you need to continue working after encountering a supported Windows Codex sandbox execution problem, Codex Sandbox Doctor Pro provides additional recovery features.

**Codex Sandbox Doctor Pro — $9.99 one-time purchase**

[Purchase Codex Sandbox Doctor Pro on Ko-fi](https://ko-fi.com/s/f1ad1cb641)

Pro features include:

- Automatic project detection from your instructions
- Windows sandbox mode comparison
- Verified recovery-mode selection
- Consent-based alternative sandbox execution
- Recovery command generation
- Copying commands for your existing PowerShell terminal
- Support for optional saved Codex session selection
- Keeping your existing model and reasoning settings

With Pro, you can prepare a validated command and run Codex from the terminal you normally use.

**Pro does not guarantee recovery from every Codex error.**

This is a one-time purchase, not a subscription.

## 10. Security Software Notice

Codex Sandbox Doctor is a Windows utility developed to diagnose Codex errors and help users continue their work. Its diagnostic and recovery features have been successfully tested in a real Windows environment.

Some security programs, including AhnLab, may display alerts during Codex or PowerShell operations. These alerts can occur during normal development automation.

**If an alert appears but the program works normally, simply continue.**

If execution is blocked, you can check the downloaded file with your antivirus software or VirusTotal. If you choose to temporarily disable the interfering protection to retry, restore it after completing your work.

## 11. Compatibility and privacy

### Operating system

Codex Sandbox Doctor Free is designed for Windows environments.

### Verified Codex version

Codex CLI `0.162.1` has been tested in the development environment.

Other versions may be supported, but compatibility can vary depending on changes to Codex.

### Diagnostic information

The application analyzes locally stored Codex logs and installation information.

It is designed to mask common Windows user-profile paths in diagnostic reports.

### Existing projects

The Free diagnostic does not intentionally edit your software projects, modify authentication information, or terminate existing Codex sessions.

### Independent software

Codex Sandbox Doctor is independently developed and is not an official OpenAI product.

## 12. Quick Start

1. Download the Free ZIP file.
2. Extract the ZIP.
3. Double-click `CodexSandboxDoctor-Free.exe`.
4. Choose your language.
5. Click `Run Free Diagnostic`.
6. Click `View Report`.
7. Read the diagnostic results.

**Codex Sandbox Doctor Free helps you understand the problem before deciding on a recovery method.**

**Codex CLI Version Compatibility**

Codex Sandbox Doctor is designed to support different Codex CLI versions rather than being restricted to one specific version.

The recovery workflow has been successfully tested with Codex CLI 0.162.1 in a real Windows environment.

Other versions may behave differently, and compatibility with every version is not guaranteed.

The application is also designed with future Codex CLI versions in mind. If future versions continue to support the same sandbox configuration options and experience compatible execution errors, the recovery workflow may remain applicable without changes.

If OpenAI changes its command-line options, sandbox architecture, or execution behavior, an application update may be required.

---

# PART 2 — 한국어 사용설명서

## 1. 프로그램 소개

Codex Sandbox Doctor Free는 Windows 환경에서 발생하는 OpenAI Codex CLI의 실행 오류를 진단하기 위해 제작한 무료 프로그램입니다.

Codex 프로그램은 정상적으로 열리지만 내부 PowerShell 명령이나 개발 명령이 실행되지 않는 경우가 있습니다.

Codex Sandbox Doctor Free는 설치된 Codex 환경과 저장된 오류 기록을 분석하여 이러한 문제를 이해할 수 있도록 도와줍니다.

**Codex Sandbox Doctor Free는 무료로 사용할 수 있습니다.**

Free는 오류 진단과 보고서 제공을 담당하며, 실제 우회 실행 기능은 Codex Sandbox Doctor Pro에서 제공됩니다.

## 2. 다운로드 및 프로그램 실행

**1단계 — Codex Sandbox Doctor Free 실행**

1. 공식 배포 페이지에서 `CodexSandboxDoctor-Free.zip`을 다운로드합니다.
2. 다운로드한 ZIP 파일의 압축을 해제합니다.
3. `CodexSandboxDoctor-Free.exe`를 더블클릭합니다.
4. 무료 진단 프로그램 화면이 열립니다.

PowerShell 명령어를 직접 입력할 필요가 없습니다.

**사진 01 — 영어 초기 화면**

![Screenshot 01](images/01.jpg)

초기 화면에는 현재 설치된 Codex 버전, 진단 대상, 로그 검사 위치와 검사 범위 등이 표시됩니다.

**개별 프로젝트 폴더를 선택할 필요는 없습니다.**

## 3. 한국어·영어 변경

**2단계 — 언어 선택**

프로그램 상단의 언어 선택 메뉴에서 `English` 또는 `한국어`를 선택합니다.

**사진 02 — 한국어 초기 화면**

![Screenshot 02](images/02.jpg)

화면 언어를 변경할 수 있으며, 상세 보고서에서는 주요 영어 오류명에 대한 한국어 설명도 확인할 수 있습니다.

## 4. 무료 진단 실행

**3단계 — 무료 진단 실행 버튼 클릭**

`무료 진단 실행` 버튼을 클릭합니다.

프로그램은 다음 정보를 확인합니다.

- Codex CLI 설치 여부
- 설치된 Codex 버전
- Codex 실행 파일 경로
- Windows 샌드박스 오류 로그
- 주요 오류 발생 기록
- 과거 오류 누적 횟수
- 관련 실행 프로세스

무료 진단은 기존 Codex 설정이나 인증정보, 작업 세션을 변경하는 복구 작업을 수행하지 않습니다.

**사진 03 — 무료 진단 결과 화면**

![Screenshot 03](images/03.jpg)

### 진단 결과의 의미

**진단 실행: PASS**

무료 진단이 정상적으로 완료됐다는 뜻입니다.

**과거 오류 발견**

저장된 로그에서 해당 오류 기록이 발견됐다는 뜻입니다.

**현재 오류 재현: 미실시**

현재 실행 환경에서 오류를 직접 다시 재현하는 테스트는 수행하지 않았습니다.

**복구 실행: 미실행**

무료 버전에서는 복구 작업을 실행하지 않았습니다.

진단 완료와 실제 복구 완료는 서로 다른 결과입니다.

## 5. 상세 보고서 확인

**4단계 — 보고서 보기 버튼 클릭**

무료 진단이 끝나면 `보고서 보기` 버튼을 클릭합니다.

발견된 오류와 설명이 포함된 보고서를 확인할 수 있습니다.

**사진 04 — 상세 보고서**

![Screenshot 04](images/04.jpg)

보고서에는 Codex 버전, 검사한 로그 기간, 누적 오류 횟수와 주요 오류 설명이 나옵니다.

### 주요 Codex 오류

**A. `setup refresh had errors`**

샌드박스 실행 환경 초기화 또는 갱신 과정에서 오류가 발생했다는 뜻입니다.

Codex 창이 정상적으로 열리더라도 내부 PowerShell이나 개발 명령이 실행되지 않을 수 있습니다.

**B. `helper_unknown_error`**

Codex 실행 도우미 초기화 과정에서 알 수 없는 오류가 발생했다는 뜻입니다.

정확한 원인 분석을 위해 추가적인 실행 증거가 필요할 수 있습니다.

**C. `os error 32`**

Windows 파일 공유 충돌 오류입니다.

다른 프로세스에서 파일을 사용하고 있어 업데이트 또는 접근 과정에서 충돌이 발생할 수 있습니다.

**D. `os error 5`**

Windows 접근 권한 거부 오류입니다.

권한이나 실행 환경 제한 등과 관련될 수 있습니다.

### 과거 오류와 현재 오류의 차이

보고서에 표시되는 오류 횟수는 저장된 과거 로그를 검사해서 발견한 기록입니다.

예를 들어 오류가 300회 표시됐다고 해서 현재 300개의 오류가 발생하고 있는 것은 아닙니다.

## 6. 무료 버전의 진단 범위

Codex Sandbox Doctor Free에서 확인할 수 있는 항목은 다음과 같습니다.

1. Codex CLI 설치 여부 확인
2. Codex 버전 확인
3. Codex 실행 파일 위치 확인
4. 저장된 샌드박스 오류 로그 분석
5. 지원하는 오류 메시지 탐지
6. 과거 오류 발생 횟수 확인
7. 관련 프로세스 정보 확인
8. 진단 보고서 생성

### 무료 버전에서 지원하지 않는 기능

- Codex 자동복구
- Windows 샌드박스 설정 변경
- 실행 중인 Codex 세션 강제 종료
- 모든 로그인·인증 오류 해결
- npm·Node.js의 모든 설치 오류 복구
- 인터넷 및 서버 연결 장애 복구
- 새롭게 발생한 모든 미등록 오류 탐지
- 검증된 우회 실행 명령 생성

무료 버전은 문제를 찾아 이해하도록 돕는 진단 도구입니다.

## 7. 문제가 발생한 Codex 창을 열어둬야 하나요?

**아니요.**

Codex 창이 열려 있거나 닫혀 있어도 Free 진단을 실행할 수 있습니다.

프로그램은 주로 PC에 설치된 Codex 실행 환경과 저장된 오류 기록을 검사합니다.

다만 현재 실행 중인 프로세스 관련 정보를 함께 확인하고 싶다면 문제가 발생한 Codex 창을 열어둔 상태가 도움이 될 수 있습니다.

## 8. PASS·PARTIAL·HOLD·FAIL의 의미

**PASS — 통과**

해당 진단 또는 검증 작업이 정상 완료됐다는 뜻입니다.

**PARTIAL — 부분 확인**

일부 정보는 확인됐지만 전체 작업에 필요한 증거가 충분하지 않은 상태입니다.

**HOLD — 보류**

해당 작업을 지금은 확인하거나 안전하게 완료할 수 없는 상태입니다.

**FAIL — 실패**

실제 증거에 따라 해당 작업이 실패한 상태입니다.

**참고:** 무료 진단 PASS가 Codex 복구 PASS를 의미하는 것은 아닙니다.

## 9. Codex Sandbox Doctor Pro로 개발 계속하기

Windows Codex 샌드박스 오류로 개발 작업을 진행할 수 없다면, Codex Sandbox Doctor Pro에서 지원하는 복구 기능을 이용할 수 있습니다.

**Codex Sandbox Doctor Pro — $9.99 일회성 구매**

[Ko-fi에서 Codex Sandbox Doctor Pro 구매하기](https://ko-fi.com/s/f1ad1cb641)

Pro에서는 다음 기능을 제공합니다.

- 원본 지시문 기반 프로젝트 자동 탐색
- Windows 샌드박스 모드 비교
- 검증된 우회 방식 선택
- 사용자 동의 기반 Sandbox 우회
- 복구 명령 자동 생성
- 기존 PowerShell 터미널용 명령 복사
- 저장된 Codex 세션 선택적 재개 지원
- 기존 Codex 모델·추론 설정 유지

Pro에서는 검증된 우회 명령을 생성하고, 사용자가 평소 사용하던 PowerShell에서 Codex를 실행하여 개발 작업을 이어갈 수 있도록 지원합니다.

**다만 모든 Codex 오류의 복구를 보장하는 제품은 아닙니다.**

Pro는 월 구독이 아닌 일회성 구매 방식입니다.

## 10. 보안 프로그램 안내

Codex Sandbox Doctor는 Codex 실행 오류를 진단하고 개발 작업을 계속할 수 있도록 제작한 Windows 프로그램입니다. 실제 Windows 환경에서 진단과 복구 기능의 정상 작동을 확인했습니다.

Codex Sandbox Doctor 사용 중 AhnLab 등 일부 보안 프로그램에서 경고가 표시될 수 있습니다. 이는 정상적인 Codex 및 PowerShell 자동화 작업에서도 발생하는 현상입니다.

**경고가 표시되더라도 프로그램이 정상 작동한다면 걱정하지 마시고 그대로 진행하시면 됩니다.**

실행이 차단되는 경우 백신 프로그램이나 VirusTotal로 파일을 검사할 수 있습니다. 필요에 따라 해당 보안 기능을 일시적으로 해제해 다시 시도할 수 있으며, 작업 완료 후 보호 기능을 복원하면 됩니다.

## 11. 호환성과 개인정보

### 운영체제

Windows 환경의 Codex CLI를 대상으로 제작했습니다.

### 실제 검증 버전

Codex CLI `0.162.1`에서 실제 테스트를 진행했습니다.

다른 버전에서도 사용할 수 있도록 설계했지만, Codex 업데이트에 따라 일부 기능의 호환성이 달라질 수 있습니다.

### 진단 정보

설치된 Codex 환경과 PC에 저장된 오류 로그를 분석합니다.

진단 보고서에서는 일반적인 Windows 사용자 프로필 경로를 가리도록 설계했습니다.

### 기존 프로젝트 보호

Free 진단은 기존 프로젝트 파일, Codex 인증정보 및 작업 세션을 변경하는 복구 작업을 수행하지 않습니다.

### 독립 소프트웨어

Codex Sandbox Doctor는 독립적으로 개발한 프로그램이며 OpenAI의 공식 제품이 아닙니다.

## 12. 빠른 시작 요약

1. Free ZIP 파일 다운로드
2. ZIP 압축 해제
3. `CodexSandboxDoctor-Free.exe` 더블클릭
4. 언어 선택
5. `무료 진단 실행` 클릭
6. `보고서 보기` 클릭
7. 발견된 오류와 설명 확인

**Codex Sandbox Doctor Free는 오류의 원인을 이해하고, 필요한 복구 방법을 판단하는 데 도움을 줍니다.**

**Codex CLI 버전 호환성 안내**

Codex Sandbox Doctor는 특정 Codex CLI 버전에만 고정되지 않고 다양한 버전에서 사용할 수 있도록 설계되었습니다.

실제 Windows 환경에서 Codex CLI 0.162.1을 이용한 복구 및 개발 작업 재개에 성공했습니다.

다른 버전에서는 동작이 달라질 수 있으며, 모든 버전의 호환성을 보장하지는 않습니다.

또한 향후 출시되는 Codex CLI 버전도 고려하여 설계했습니다. 향후 버전에서도 동일한 샌드박스 설정 옵션이 유지되고 지원 가능한 유형의 실행 오류가 발생한다면 기존 복구 절차를 그대로 활용할 수 있습니다.

OpenAI가 명령 옵션, 샌드박스 구조 또는 실행 방식을 변경할 경우 프로그램 업데이트가 필요할 수 있습니다.

---

# PRODUCT INFORMATION / 제품 정보

**Product:** Codex Sandbox Doctor Free  
**Platform:** Windows  
**Type:** Codex CLI Diagnostic Utility  
**Price:** Free  
**Languages:** English / Korean  
**Recovery:** Available separately in Pro  

**제품명:** Codex Sandbox Doctor Free  
**운영체제:** Windows  
**종류:** Codex CLI 무료 진단 프로그램  
**가격:** 무료  
**언어:** 영어 / 한국어  
**복구 기능:** Pro 버전에서 별도 제공

**Codex Sandbox Doctor is an independent utility, not an official OpenAI product.**

**Codex Sandbox Doctor는 OpenAI 공식 제품이 아닌 독립 개발 도구입니다.**

---

**Notice About Screenshots**

Some screenshots in this guide were captured when the software was named "Codex Rescue."

The product has since been renamed **Codex Sandbox Doctor**. The screenshots show the same application workflow, and the instructions remain applicable to the current version.

**스크린샷 제품명 안내**

이 설명서에 사용된 일부 화면은 제품명이 "Codex Rescue"였을 때 촬영한 이미지입니다.

현재 제품명은 **Codex Sandbox Doctor**로 변경되었습니다. 이미지에 표시된 프로그램의 사용 절차는 동일하며, 본 설명서는 현재 버전에도 그대로 적용됩니다.
