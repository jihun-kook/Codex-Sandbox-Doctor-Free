# Codex Sandbox Doctor Free

Codex Sandbox Doctor Free is the public, diagnostic-only Windows edition for Codex CLI startup and sandbox errors.

After extracting the ZIP, double-click the HTML User Guide to view the step-by-step instructions with screenshots. No internet connection is required.

ZIP 파일의 압축을 해제한 후 HTML 사용설명서를 더블클릭하세요. 인터넷 연결 없이 실제 화면 사진과 단계별 사용 방법을 확인할 수 있습니다.

## English guide

1. Extract `CodexSandboxDoctor-Free.zip`.
2. Double-click `CodexSandboxDoctor-Free.exe`. Only the GUI should appear; no console window is required.
3. Select **English** or **한국어**, then choose **Run free diagnostic**.
4. Review the independent results:
   - **Diagnostic execution: PASS** means the diagnostic itself completed.
   - **Errors found in historical logs** reports cumulative matches in the inspected past logs. It does not mean the error was reproduced now.
   - **Current error reproduction: NOT PERFORMED** means Free did not reproduce the failure.
   - **Recovery execution: NOT RUN** means no recovery action was attempted.
5. Choose **View report**, or open the generated file in the adjacent `diagnostics` folder.

The screen and report identify the diagnostic target as this PC's shared Codex CLI runtime environment. They show the installed Codex version, privacy-masked executable path, inspected log folder, file count, inspection period, and cumulative historical matches. Individual projects are not inspected.

Free creates only its diagnostic report. It does not repair, terminate processes, change permissions, disable or bypass security, edit Codex configuration, touch authentication, or modify existing files, sessions, settings, and projects. Windows PowerShell 5.1 is supported.

The public ZIP contains `CodexSandboxDoctor-Free.exe`, this `README.md`, the detailed `CodexSandboxDoctor-Free-Guide.md`, the offline `CodexSandboxDoctor-Free-Guide.html`, the `images` folder with four Free screenshots, and `SHA256.txt`. It contains no Pro executable, Pro source, recovery command, secret information, or Pro implementation detail.

### Codex Sandbox Doctor Pro

Free remains free for diagnostics. Codex Sandbox Doctor Pro is a separate **$9.99 one-time purchase** that adds comparison and recovery workflows; it is not a subscription.

[Purchase Codex Sandbox Doctor Pro on Ko-fi](https://ko-fi.com/s/f1ad1cb641)

## 한국어 사용설명서

1. `CodexSandboxDoctor-Free.zip`의 압축을 풉니다.
2. `CodexSandboxDoctor-Free.exe`를 더블클릭합니다. 검은 콘솔 창 없이 GUI만 표시되어야 합니다.
3. **English** 또는 **한국어**를 선택한 후 **무료 진단 실행**을 누릅니다.
4. 서로 분리된 결과를 확인합니다.
   - **진단 실행: PASS**는 진단 자체가 정상 완료되었다는 뜻입니다.
   - **과거 로그 오류 발견**은 검사한 과거 로그의 누적 발견치입니다. 현재 오류가 재현되었다는 뜻이 아닙니다.
   - **현재 오류 재현: 미실시**는 Free가 오류를 다시 발생시키지 않았다는 뜻입니다.
   - **복구 실행: 미실행**은 복구 작업을 수행하지 않았다는 뜻입니다.
5. **보고서 보기**를 누르거나 실행 파일 옆 `diagnostics` 폴더의 보고서를 엽니다.

화면과 보고서는 진단 대상을 **이 PC의 Codex CLI 공통 실행 환경**으로 표시합니다. 설치된 Codex 버전, 개인정보가 마스킹된 실행 파일 경로, 검사한 로그 폴더·파일 수·기간, 과거 로그 누적 발견치를 함께 보여 줍니다. 개별 프로젝트는 검사하지 않습니다.

Free는 진단 보고서 파일만 생성합니다. 복구, 프로세스 종료, 권한 변경, 보안 기능 비활성화 또는 우회, Codex 설정 편집, 인증 변경, 기존 파일·세션·설정·프로젝트 변경을 수행하지 않습니다. Windows PowerShell 5.1을 지원합니다.

공개 ZIP에는 `CodexSandboxDoctor-Free.exe`, 이 `README.md`, 상세 사용설명서 `CodexSandboxDoctor-Free-Guide.md`, 오프라인 `CodexSandboxDoctor-Free-Guide.html`, Free 스크린샷 4장이 들어 있는 `images` 폴더, `SHA256.txt`가 포함됩니다. Pro 실행 파일·소스·복구 명령·비밀정보·Pro 구현 내부 정보는 포함하지 않습니다.

### Codex Sandbox Doctor Pro 안내

Free는 무료 진단판으로 계속 사용할 수 있습니다. 비교 및 복구 절차를 제공하는 Codex Sandbox Doctor Pro는 별도의 **$9.99 일회성 구매** 제품이며 구독 상품이 아닙니다.

[Ko-fi에서 Codex Sandbox Doctor Pro 구매하기](https://ko-fi.com/s/f1ad1cb641)
